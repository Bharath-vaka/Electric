<?php

// Connect to your database
$host = "localhost";
$user = "id20421793_bharath";
$pass = "Bharath@2592";
$dbname = "id20421793_demo";
$conn = mysqli_connect($host, $user, $pass, $dbname);

?>